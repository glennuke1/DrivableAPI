﻿using MSCLoader;
using UnityEngine;

namespace DrivableAPI
{
    public class DrivableAPI : Mod
    {
        public override string ID => "DrivableAPI"; //Your mod ID (unique)
        public override string Name => "DrivableAPI"; //You mod name
        public override string Author => "0387"; //Your Username
        public override string Version => "1.0"; //Version
        public override string Description => ""; //Short description of your mod

        public override void ModSetup()
        {
            SetupFunction(Setup.OnLoad, Mod_OnLoad);
        }

        private void Mod_OnLoad()
        {
            ModConsole.Log("Drivable API Loaded");
        }

        public static DrivingMode AddDrivingMode(GameObject carRoot, string carCustomName, Vector3 drivingModeOffset)
        {
            Transform playerTrigger = carRoot.transform.Find("PlayerTrigger");

            if (playerTrigger == null)
            {
                ModConsole.Log("[Drivable API] Please set up PlayerTrigger inside unity");
                return null;
            }

            playerTrigger.gameObject.layer = LayerMask.NameToLayer("PlayerOnlyColl");
            Transform DriveTrigger = playerTrigger.Find("DriveTrigger");
            
            if (DriveTrigger == null)
            {
                ModConsole.Log("[Drivable API] Please set up DriveTrigger under PlayerTrigger inside unity");
                return null;
            }

            DriveTrigger.gameObject.layer = LayerMask.NameToLayer("PlayerOnlyColl");

            playerTrigger.gameObject.AddComponent<PlayerCarTrigger>();

            DrivingMode drivingMode = DriveTrigger.gameObject.AddComponent<DrivingMode>();
            drivingMode.offset = drivingModeOffset;
            drivingMode.AxisCarController = carRoot.GetComponent<AxisCarController>();
            drivingMode.PlayerPivotObject = DriveTrigger;
            drivingMode.carCustomName = carCustomName;

            return drivingMode;
        }

        public static void AddGearIndicator(GameObject carRoot, string carCustomName, bool automatic)
        {
            GearIndicator gearIndicator = carRoot.AddComponent<GearIndicator>();
            gearIndicator.carCustomName = carCustomName;
            gearIndicator.automatic = automatic;
        }
    }
}
